from flask import Flask, request, jsonify, render_template, redirect, url_for, session
from models import db,User, Product, Cart, PaymentConfig
from payment.wechat import WeChatPayment
from payment.alipay import AliPayment
import logging
from flask import Flask
import os
from dotenv import load_dotenv
import os

# 配置日志
logging.basicConfig(filename='app.log', level=logging.DEBUG)

# 初始化 Flask 应用
app = Flask(__name__)
app.secret_key = 'your_secret_key'  # 设置会话密钥
# 配置 SQLite 数据库
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'database.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# 初始化数据库
db.init_app(app)

# 加载 .env 文件
load_dotenv()


# 支付配置页面
@app.route('/config/payment', methods=['GET', 'POST'])
def config_payment():
    if request.method == 'POST':
        # 获取表单数据
        payment_type = request.form['payment_type']
        app_id = request.form['app_id']
        merchant_private_key = request.form.get('merchant_private_key')
        app_cert_path = request.form.get('app_cert_path')
        alipay_root_cert_path = request.form.get('alipay_root_cert_path')
        alipay_public_cert_path = request.form.get('alipay_public_cert_path')
        mch_id = request.form.get('mch_id')
        api_key = request.form.get('api_key')
        cert_path = request.form.get('cert_path')
        key_path = request.form.get('key_path')

        # 保存支付配置到数据库
        config = PaymentConfig(
            payment_type=payment_type,
            app_id=app_id,
            merchant_private_key=merchant_private_key,
            app_cert_path=app_cert_path,
            alipay_root_cert_path=alipay_root_cert_path,
            alipay_public_cert_path=alipay_public_cert_path,
            mch_id=mch_id,
            api_key=api_key,
            cert_path=cert_path,
            key_path=key_path
        )
        db.session.add(config)
        db.session.commit()
        return redirect(url_for('home'))
    return render_template('config_payment.html')

    

# 商品配置页面
@app.route('/config/product', methods=['GET', 'POST'])
def config_product():
    if request.method == 'POST':
        name = request.form['name']
        price = float(request.form['price'])
        description = request.form.get('description')
        image = request.form.get('image')

        # 保存商品到数据库
        product = Product(name=name, price=price, description=description, image=image)
        db.session.add(product)
        db.session.commit()
        return redirect(url_for('products'))
    return render_template('config_product.html')

# 首页
@app.route('/')
def home():
    return render_template('index.html')

# 会员注册页面
@app.route('/register', methods=['GET', 'POST'])
def register():
    error = None
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # 检查用户名是否已存在
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            error = "Username already exists. Please choose a different username."
        else:
            # 创建新用户
            new_user = User(username=username, password=password)
            db.session.add(new_user)
            db.session.commit()
            return redirect(url_for('login'))
    return render_template('register.html', error=error)

# 登录页面
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and user.password == password:
            session['user_id'] = user.id
            return redirect(url_for('home'))
        return "Invalid username or password", 401
    return render_template('login.html')

# 商品展示页面
@app.route('/products')
def products():
    products = Product.query.all()
    return render_template('products.html', products=products)

# 添加商品到购物车
@app.route('/add_to_cart/<int:product_id>', methods=['POST'])
def add_to_cart(product_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    user_id = session['user_id']
    cart_item = Cart.query.filter_by(user_id=user_id, product_id=product_id).first()
    if cart_item:
        cart_item.quantity += 1
    else:
        cart_item = Cart(user_id=user_id, product_id=product_id)
        db.session.add(cart_item)
    db.session.commit()
    return redirect(url_for('cart'))

# 购物车页面
@app.route('/cart')
def cart():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    user_id = session['user_id']
    cart_items = Cart.query.filter_by(user_id=user_id).all()
    total = sum(item.product.price * item.quantity for item in cart_items)
    return render_template('cart.html', cart_items=cart_items, total=total)

# 付款页面
@app.route('/payment')
def payment():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('payment.html')
# 支付宝支付
@app.route('/api/payment/alipay', methods=['POST'])
def alipay_pay():
    # 从数据库加载支付宝配置
    config = PaymentConfig.query.filter_by(payment_type="alipay").first()
    if not config:
        return jsonify({"error": "支付宝配置未找到"}), 400

    # 初始化支付宝支付
    alipay_payment = AliPayment(
        app_id=config.app_id,
        merchant_private_key=config.merchant_private_key,
        app_cert_path=config.app_cert_path,
        alipay_root_cert_path=config.alipay_root_cert_path,
        alipay_public_cert_path=config.alipay_public_cert_path
    )

    # 创建支付订单
    data = request.json
    pay_url = alipay_payment.create_order(
        out_trade_no=data['out_trade_no'],
        total_amount=data['total_amount'],
        subject=data['subject']
    )
    return jsonify({'pay_url': pay_url})

# 微信支付
@app.route('/api/payment/wechat', methods=['POST'])
def wechat_pay():
    # 从数据库加载微信支付配置
    config = PaymentConfig.query.filter_by(payment_type="wechat").first()
    if not config:
        return jsonify({"error": "微信支付配置未找到"}), 400

    # 初始化微信支付
    wechat_payment = WeChatPayment(
        appid=config.app_id,
        mch_id=config.mch_id,
        api_key=config.api_key,
        cert_path=config.cert_path,
        key_path=config.key_path
    )

    # 创建支付订单
    data = request.json
    order = wechat_payment.create_order(
        out_trade_no=data['out_trade_no'],
        total_fee=data['total_fee'],
        description=data['description'],
        notify_url='https://yourdomain.com/api/payment/wechat/notify'
    )
    return jsonify(order)

# 微信支付回调
@app.route('/api/payment/wechat/notify', methods=['POST'])
def wechat_notify():
    # 从数据库加载微信支付配置
    config = PaymentConfig.query.filter_by(payment_type="wechat").first()
    if not config:
        return jsonify({"error": "微信支付配置未找到"}), 400

    # 初始化微信支付
    wechat_payment = WeChatPayment(
        appid=config.app_id,
        mch_id=config.mch_id,
        api_key=config.api_key,
        cert_path=config.cert_path,
        key_path=config.key_path
    )

    # 处理回调
    success, result = wechat_payment.handle_notify(request.data)
    if success:
        # 处理支付成功逻辑
        return jsonify({'code': 'SUCCESS'})
    return jsonify({'code': 'FAIL'})


# 启动 Flask 应用
if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # 创建数据库表
    app.run(debug=True)