from alipay import AliPay, AliPayConfig

class AliPayment:
    def __init__(self, app_id, merchant_private_key, app_cert_path, alipay_root_cert_path, alipay_public_cert_path):
        # 初始化支付宝支付
        self.alipay = AliPay(
            appid=app_id,
            app_notify_url=None,
            app_private_key_string=merchant_private_key,
            alipay_public_key_string=None,
            sign_type="RSA2",
            debug=False,
            config=AliPayConfig(
                app_cert_path=app_cert_path,
                alipay_root_cert_path=alipay_root_cert_path,
                alipay_public_cert_path=alipay_public_cert_path
            )
        )

    def create_order(self, out_trade_no, total_amount, subject):
        # 创建支付宝支付订单
        order_string = self.alipay.api_alipay_trade_page_pay(
            out_trade_no=out_trade_no,
            total_amount=total_amount,
            subject=subject,
            return_url="https://yourdomain.com/return",  # 支付完成后跳转的页面
            notify_url="https://yourdomain.com/notify"  # 支付结果异步通知地址
        )
        return f"https://openapi.alipay.com/gateway.do?{order_string}"

    def handle_notify(self, data):
        # 处理支付宝回调
        success = self.alipay.verify(data, data.get('sign'))
        if success:
            return True, data
        return False, None