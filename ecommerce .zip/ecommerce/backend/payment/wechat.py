from wechatpayv3 import WeChatPay, WeChatPayType

class WeChatPayment:
    def __init__(self, appid, mch_id, api_key, cert_path, key_path):
        # 初始化微信支付
        self.wechatpay = WeChatPay(
            wechatpay_type=WeChatPayType.NATIVE,
            mchid=mch_id,
            private_key=key_path,
            cert_serial_no='YOUR_CERT_SERIAL_NO',  # 证书序列号
            apiv3_key=api_key,
            appid=appid,
            cert_dir='path_to_cert_dir'  # 证书目录
        )

    def create_order(self, out_trade_no, total_fee, description, notify_url):
        # 创建微信支付订单
        result = self.wechatpay.order.create(
            description=description,
            out_trade_no=out_trade_no,
            amount={"total": int(total_fee * 100)},  # 微信支付金额单位为分
            currency='CNY',
            notify_url=notify_url
        )
        return result

    def handle_notify(self, data):
        # 处理微信支付回调
        success, result = self.wechatpay.callback.verify(data)
        if success:
            return True, result
        return False, None