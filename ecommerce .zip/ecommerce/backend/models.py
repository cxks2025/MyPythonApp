from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(120), nullable=False)

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    price = db.Column(db.Float, nullable=False)
    description = db.Column(db.String(200))
    image = db.Column(db.String(200))

class Cart(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    quantity = db.Column(db.Integer, default=1)

    # 添加关系字段
    product = db.relationship('Product', backref='carts')

class PaymentConfig(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    payment_type = db.Column(db.String(50), nullable=False)  # 支付类型：wechat/alipay
    app_id = db.Column(db.String(100), nullable=False)  # 支付应用的 AppID
    merchant_private_key = db.Column(db.String(2000))  # 商户私钥（支付宝）
    app_cert_path = db.Column(db.String(200))  # 应用公钥证书路径（支付宝）
    alipay_root_cert_path = db.Column(db.String(200))  # 支付宝根证书路径
    alipay_public_cert_path = db.Column(db.String(200))  # 支付宝公钥证书路径
    mch_id = db.Column(db.String(100))  # 商户号（微信支付）
    api_key = db.Column(db.String(200))  # API 密钥（微信支付）
    cert_path = db.Column(db.String(200))  # 证书路径（微信支付）
    key_path = db.Column(db.String(200))  # 私钥路径（微信支付）