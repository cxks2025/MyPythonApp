from extensions import db  # 导入 db 实例
from werkzeug.security import generate_password_hash, check_password_hash
from extensions import db

# 电子卡回收商品表
class RecycleProduct(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)  # 商品名称
    price = db.Column(db.Float, nullable=False)       # 回收价格
    description = db.Column(db.String(500))          # 商品描述
    image = db.Column(db.String(200))                # 商品图片

# 电子卡售卖商品表
class SaleProduct(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)  # 商品名称
    price = db.Column(db.Float, nullable=False)       # 售卖价格
    stock = db.Column(db.Integer, nullable=False)     # 库存
    description = db.Column(db.String(500))          # 商品描述
    image = db.Column(db.String(200))                # 商品图片

# 订单表
class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)  # 用户 ID
    product_id = db.Column(db.Integer, nullable=False)  # 商品 ID
    quantity = db.Column(db.Integer, nullable=False)    # 数量
    total_amount = db.Column(db.Float, nullable=False)  # 总金额
    payment_method = db.Column(db.String(50), nullable=False)  # 付款方式
    status = db.Column(db.String(50), default='pending')  # 订单状态

# 支付通道表
class PaymentChannel(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    channel_type = db.Column(db.String(50), nullable=False)  # 通道类型（支付宝、微信、银行卡）
    account_name = db.Column(db.String(100), nullable=False)  # 收款人姓名
    account_number = db.Column(db.String(100), nullable=False)  # 收款账号
    bank_name = db.Column(db.String(100))  # 开户行（仅银行卡需要）

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    price = db.Column(db.Numeric(10, 2), nullable=False)
    description = db.Column(db.String(500))
    image = db.Column(db.String(500))

class Cart(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    quantity = db.Column(db.Integer, default=1)

    # 关系字段
    product = db.relationship('Product', backref='carts')
    user = db.relationship('User', backref='carts')

class PaymentConfig(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    payment_type = db.Column(db.String(50), nullable=False)  # 支付类型：wechat/alipay
    app_id = db.Column(db.String(100), nullable=False)  # 支付应用的 AppID
    merchant_private_key = db.Column(db.String(2000))  # 商户私钥（支付宝）
    app_cert_path = db.Column(db.String(500))  # 应用公钥证书路径（支付宝）
    alipay_root_cert_path = db.Column(db.String(500))  # 支付宝根证书路径
    alipay_public_cert_path = db.Column(db.String(500))  # 支付宝公钥证书路径
    mch_id = db.Column(db.String(100))  # 商户号（微信支付）
    api_key = db.Column(db.String(200))  # API 密钥（微信支付）
    cert_path = db.Column(db.String(500))  # 证书路径（微信支付）
    key_path = db.Column(db.String(500))  # 私钥路径（微信支付）