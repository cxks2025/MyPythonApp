def validate_username(username):
    return 2 <= len(username) <= 10

def validate_password(password):
    return 6 <= len(password) <= 128

def validate_payment_config(form_data):
    required_fields = ['payment_type', 'app_id']
    for field in required_fields:
        if field not in form_data or not form_data[field]:
            return False
    return True