from flask import Flask, render_template
from extensions import db  # 导入 db 实例
from models import RecycleProduct, SaleProduct  # 导入模型
from dotenv import load_dotenv
import os
import logging

# 加载环境变量
load_dotenv()

# 配置日志
logging.basicConfig(filename='app.log', level=logging.DEBUG)

# 初始化 Flask 应用
app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY', 'your_secret_key')

# 配置数据库
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URI', 'sqlite:///database.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# 注册应用
db.init_app(app)

# 注册路由
from routes.auth import auth_bp
from routes.payment import payment_bp
from routes.product import product_bp
from routes.cart import cart_bp
from routes.admin import admin_bp

app.register_blueprint(auth_bp)
app.register_blueprint(payment_bp)
app.register_blueprint(product_bp)
app.register_blueprint(cart_bp)
app.register_blueprint(admin_bp)

# 首页路由
@app.route('/')
def home():
    return render_template('index.html')

# 创建数据库表并插入测试数据
with app.app_context():
    db.create_all()

    # 清空现有数据（可选）
    db.session.query(RecycleProduct).delete()
    db.session.query(SaleProduct).delete()
    db.session.commit()

    # 插入电子卡回收商品
    recycle_products = [
        RecycleProduct(name='京东E卡 100元', price=85, description='京东商城通用电子卡，可用于购买京东自营商品。'),
        RecycleProduct(name='天猫超市卡 50元', price=42, description='天猫超市专用电子卡，可用于购买天猫超市商品。'),
        RecycleProduct(name='星巴克电子卡 30元', price=25, description='星巴克专用电子卡，可用于全国星巴克门店消费。'),
        RecycleProduct(name='腾讯视频VIP月卡', price=20, description='腾讯视频VIP会员月卡，可用于观看VIP内容。'),
        RecycleProduct(name='网易云音乐黑胶VIP月卡', price=15, description='网易云音乐黑胶VIP会员月卡，可用于享受无损音质和专属权益。'),
    ]
    db.session.bulk_save_objects(recycle_products)

    # 插入电子卡售卖商品
    sale_products = [
        SaleProduct(name='京东E卡 100元', price=100, stock=100, description='京东商城通用电子卡，可用于购买京东自营商品。'),
        SaleProduct(name='天猫超市卡 50元', price=50, stock=200, description='天猫超市专用电子卡，可用于购买天猫超市商品。'),
        SaleProduct(name='星巴克电子卡 30元', price=30, stock=150, description='星巴克专用电子卡，可用于全国星巴克门店消费。'),
        SaleProduct(name='腾讯视频VIP月卡', price=25, stock=300, description='腾讯视频VIP会员月卡，可用于观看VIP内容。'),
        SaleProduct(name='网易云音乐黑胶VIP月卡', price=18, stock=250, description='网易云音乐黑胶VIP会员月卡，可用于享受无损音质和专属权益。'),
    ]
    db.session.bulk_save_objects(sale_products)

    db.session.commit()
    print("测试数据插入成功！")

# 启动应用
if __name__ == '__main__':
    app.run(debug=True)
