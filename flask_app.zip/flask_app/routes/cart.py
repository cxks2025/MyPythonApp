from flask import Blueprint, request, redirect, url_for, render_template, flash, session
from extensions import db  # 导入 db 实例
from models import Cart, Product

# 创建 Blueprint
cart_bp = Blueprint('cart', __name__)

@cart_bp.route('/cart', methods=['GET', 'POST'])
def cart():
    if 'user_id' not in session:
        flash('Please login to access your cart.', 'error')
        return redirect(url_for('auth.login'))

    user_id = session['user_id']

    if request.method == 'POST':
        # 获取表单数据
        product_id = request.form.get('product_id')
        quantity = int(request.form.get('quantity', 1))

        # 检查商品是否存在
        product = Product.query.get(product_id)
        if not product:
            flash('Product not found.', 'error')
            return redirect(url_for('cart.cart'))

        # 检查购物车中是否已有该商品
        cart_item = Cart.query.filter_by(user_id=user_id, product_id=product_id).first()
        if cart_item:
            # 如果已有该商品，更新数量
            cart_item.quantity += quantity
        else:
            # 如果没有该商品，添加到购物车
            cart_item = Cart(user_id=user_id, product_id=product_id, quantity=quantity)
            db.session.add(cart_item)

        db.session.commit()
        flash('Product added to cart successfully.', 'success')
        return redirect(url_for('cart.cart'))

    # 获取当前用户的购物车内容
    cart_items = Cart.query.filter_by(user_id=user_id).all()
    total = sum(item.product.price * item.quantity for item in cart_items)
    return render_template('cart.html', cart_items=cart_items, total=total)

@cart_bp.route('/cart/remove/<int:cart_item_id>', methods=['POST'])
def remove_from_cart(cart_item_id):
    if 'user_id' not in session:
        flash('Please login to manage your cart.', 'error')
        return redirect(url_for('auth.login'))

    user_id = session['user_id']

    # 检查购物车项是否存在
    cart_item = Cart.query.filter_by(id=cart_item_id, user_id=user_id).first()
    if not cart_item:
        flash('Cart item not found.', 'error')
        return redirect(url_for('cart.cart'))

    # 删除购物车项
    db.session.delete(cart_item)
    db.session.commit()
    flash('Product removed from cart successfully.', 'success')
    return redirect(url_for('cart.cart'))