from flask import Blueprint, render_template, request, redirect, url_for, flash
from extensions import db
from models import SaleProduct

sale_bp = Blueprint('sale', __name__)

@sale_bp.route('/sale/products')
def sale_products():
    products = SaleProduct.query.all()
    return render_template('sale_products.html', products=products)

@sale_bp.route('/sale/product/<int:product_id>')
def sale_product_detail(product_id):
    product = SaleProduct.query.get_or_404(product_id)
    return render_template('sale_product_detail.html', product=product)