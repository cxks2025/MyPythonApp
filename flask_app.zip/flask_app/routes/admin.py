from flask import Blueprint, render_template, request, redirect, url_for, flash
from extensions import db
from models import RecycleProduct, SaleProduct, PaymentChannel

admin_bp = Blueprint('admin', __name__)

# 电子卡回收商品上传
@admin_bp.route('/admin/recycle/upload', methods=['GET', 'POST'])
def upload_recycle_product():
    if request.method == 'POST':
        name = request.form.get('name')
        price = float(request.form.get('price'))
        description = request.form.get('description')

        product = RecycleProduct(name=name, price=price, description=description)
        db.session.add(product)
        db.session.commit()
        flash('商品上传成功！', 'success')
        return redirect(url_for('admin.upload_recycle_product'))
    return render_template('upload_recycle_product.html')

# 电子卡售卖商品上传
@admin_bp.route('/admin/sale/upload', methods=['GET', 'POST'])
def upload_sale_product():
    if request.method == 'POST':
        name = request.form.get('name')
        price = float(request.form.get('price'))
        stock = int(request.form.get('stock'))
        description = request.form.get('description')

        product = SaleProduct(name=name, price=price, stock=stock, description=description)
        db.session.add(product)
        db.session.commit()
        flash('商品上传成功！', 'success')
        return redirect(url_for('admin.upload_sale_product'))
    return render_template('upload_sale_product.html')

@admin_bp.route('/admin/recycle/products')
def admin_recycle_products():
    products = RecycleProduct.query.all()
    return render_template('admin_recycle_products.html', products=products)

@admin_bp.route('/admin/sale/products')
def admin_sale_products():
    products = SaleProduct.query.all()
    return render_template('admin_sale_products.html', products=products)