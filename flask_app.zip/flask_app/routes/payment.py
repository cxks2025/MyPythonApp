from flask import Blueprint, request, redirect, url_for, flash
from extensions import db
from models import Order, PaymentChannel


# 创建 Blueprint
payment_bp = Blueprint('payment', __name__)

@payment_bp.route('/payment/recycle', methods=['POST'])
def recycle_payment():
    payment_method = request.form.get('payment_method')
    # 根据 payment_method 处理支付逻辑
    flash('支付成功！', 'success')
    return redirect(url_for('home'))

@payment_bp.route('/payment/sale', methods=['POST'])
def sale_payment():
    payment_method = request.form.get('payment_method')
    # 根据 payment_method 处理支付逻辑
    flash('支付成功！', 'success')
    return redirect(url_for('home'))

@payment_bp.route('/config/payment', methods=['GET', 'POST'])
def config_payment():
    if request.method == 'POST':
        try:
            # 检查是否已存在相同支付类型的配置
            existing_config = PaymentConfig.query.filter_by(payment_type=request.form['payment_type']).first()
            if existing_config:
                flash('Payment configuration for this type already exists.', 'error')
            else:
                config = PaymentConfig(
                    payment_type=request.form['payment_type'],
                    app_id=request.form['app_id'],
                    merchant_private_key=request.form.get('merchant_private_key'),
                    app_cert_path=request.form.get('app_cert_path'),
                    alipay_root_cert_path=request.form.get('alipay_root_cert_path'),
                    alipay_public_cert_path=request.form.get('alipay_public_cert_path'),
                    mch_id=request.form.get('mch_id'),
                    api_key=request.form.get('api_key'),
                    cert_path=request.form.get('cert_path'),
                    key_path=request.form.get('key_path')
                )
                db.session.add(config)
                db.session.commit()
                flash('Payment configuration saved successfully.', 'success')
                return redirect(url_for('home'))
        except Exception as e:
            db.session.rollback()
            flash('An error occurred while saving the payment configuration.', 'error')
    return render_template('config_payment.html')