from flask import Blueprint, render_template, request, redirect, url_for, flash
from extensions import db
from models import RecycleProduct

recycle_bp = Blueprint('recycle', __name__)

@recycle_bp.route('/recycle/products')
def recycle_products():
    products = RecycleProduct.query.all()
    return render_template('recycle_products.html', products=products)

@recycle_bp.route('/recycle/product/<int:product_id>')
def recycle_product_detail(product_id):
    product = RecycleProduct.query.get_or_404(product_id)
    return render_template('recycle_product_detail.html', product=product)