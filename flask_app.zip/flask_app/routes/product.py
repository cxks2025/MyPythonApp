from flask import Blueprint, render_template
from extensions import db  # 导入 db 实例
from models import Product

# 创建 Blueprint
product_bp = Blueprint('product', __name__)

@product_bp.route('/config/product', methods=['GET', 'POST'])
def config_product():
    if request.method == 'POST':
        name = request.form['name']
        price = float(request.form['price'])
        description = request.form.get('description')
        image = request.form.get('image')

        # 保存商品到数据库
        product = Product(name=name, price=price, description=description, image=image)
        db.session.add(product)
        db.session.commit()
        flash('Product saved successfully.', 'success')
        return redirect(url_for('product.products'))
    return render_template('config_product.html')

@product_bp.route('/products')
def products():
    products = Product.query.all()
    print("Products in database:", products)  # 调试信息
    return render_template('products.html', products=products)